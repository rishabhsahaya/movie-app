import MovieList from "./Moviecard";

function App() {
  return (
    <>
    <h1>Movie App</h1>
    <MovieList />
    </>
  );
}

export default App;
