import React from "react";
import Student from "./Student";
//or import {Component} from "react";

class Student extends React.Component{
 
    render(){
        
        return(
            <>
            
            </>
        )
        
    }
}

export default Student;